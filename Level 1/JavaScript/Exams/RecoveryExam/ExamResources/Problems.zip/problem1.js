﻿function solve(input) {
    "use strict";
    var bill = parseFloat(input[0]);
    var mood = input[1];
    var result = 0;

    if (mood === 'happy') {
        result = (bill * 0.10).toFixed(2);
    } else if (mood === 'married') {
        result = (bill * 0.0005).toFixed(2);
    } else if (mood === 'drunk') {
        var currentTips = (bill * 0.15);
        var drunkTips = currentTips + '';
        var level = Number(drunkTips[0]);
        var currentResult = Math.pow(currentTips, level);
        result = currentResult.toFixed(2);
    } else {
        result = (bill * 0.05).toFixed(2);
    }

    console.log(result);
}