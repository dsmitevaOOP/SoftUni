﻿function solve(input) {
    "use strict";
    var string = input[0];
//    var match = string.replace(/[^0-9]/g, ' ');
//    var trimMatch = (match.trim());
//    var result = trimMatch.split(' ');
//    var numbersInArr = result.filter(Number);


    var regex = /(\d+)/g;
    var result = (string.match(regex));


    var arrInHex = [];
    var hexNumbersUpCase = '';
    var output = '';

    for (var i = 0; i < result.length; i++) {
        var hexNumbers = parseInt(result[i]).toString(16);
        if (hexNumbers.length < 4) {
            while (hexNumbers.length < 4) {
                hexNumbers = '0' + hexNumbers;
            }
        }
        hexNumbersUpCase = hexNumbers.toUpperCase();
        output = '0x' + hexNumbersUpCase;
        arrInHex.push(output);
    }

    if (arrInHex.length > 1) {
        for (var j = 0; j < arrInHex.length - 1; j++) {
            arrInHex[j] += '-';
        }
        console.log(arrInHex.join(''));
    } else {
        console.log(arrInHex.join(''));
    }

}

solve(['5tffwj(//*7837xzc2---34rlxXP%$".']);
console.log('-------------');

solve(['482vMWo(*&^%$213;k!@41341((()&^>><///]42344p;e312']);
console.log('-------------');

solve(['20']);
