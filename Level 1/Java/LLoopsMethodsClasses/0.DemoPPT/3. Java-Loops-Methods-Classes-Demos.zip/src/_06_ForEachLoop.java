public class _06_ForEachLoop {
	public static void main(String[] args) {
		String[] days = { "Monday", "Tuesday", "Wednesday", "Thursday",
				"Friday", "Saturday", "Sunday" };
		for (String day : days) {
			System.out.println(day);
		}
	}
}
